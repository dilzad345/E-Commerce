

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Score Card Bowling Edit</h2>



<?php
// insert data into the database 
include('../_function.php');

?>












<?php
//getting news form the database tbl_news
$conn =  getDBconnection ();




//updating


if(isset($_POST['update_btn'])){
$id = $_POST['id'];
$bowling_teams = $_POST['bowling_teams'];
$bowler = $_POST['bowler'];
$run = $_POST['run'];
$madin = $_POST['madin'];
$wicket = $_POST['wicket'];
$economic = $_POST['economic'];
$overs = $_POST['overs'];



$query = "UPDATE tbl_scorebowl SET bowling_teams = '$bowling_teams' , bowler = '$bowler', run = '$run' , madin = '$madin', wicket = '$wicket', economic = '$economic', overs = '$overs' WHERE id = $id ";
//$query = "UPDATE tbl_news SET news_description = '$new_desc', desc2 = '$value', desc3 = ''  WHERE id = $id ";
//echo $query;
if (mysqli_query($conn, $query)) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . mysqli_error($conn);
}

}








$id = $_GET['id'];

 $sql = "SELECT * FROM tbl_scorebowl WHERE id = $id";


  $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>

<div class="alert alert-danger alert-dismissible">
  
    <td>
                <form action="a_scorecard_bowl-edit.php?id=<?php echo $row['id'] ?>" method="post">
                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <input name="bowling_teams" value="<?php echo $row['bowling_teams']?>" />
                  <input name="bowler" value="<?php echo $row['bowler']?>" />
                  <input name="run" value="<?php echo $row['run']?>" />
                  <input name="madin" value="<?php echo $row['madin']?>" />
                  <input name="wicket" value="<?php echo $row['wicket']?>" />
                  <input name="economic" value="<?php echo $row['economic']?>" />
                  <input name="overs" value="<?php echo $row['overs']?>" />
                  

                  
                  
                
                  <button type="submit" name="update_btn" class="btn btn-danger"> Update </button>

                 
                </form>
            </td>
  </div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }


?>

  





   

  




  




</div>
</div>
</body>
</html>
