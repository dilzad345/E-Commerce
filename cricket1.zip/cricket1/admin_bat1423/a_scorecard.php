

 <!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Full Score Card</h2> <br>

  



<?php
// insert data into the database 
include('../_function.php');


if (isset($_POST['btnAd'])) {

                            $bat_teams = $_POST['bat_teams'];
                            $teams = $_POST['teams'];
                            $batsman = $_POST['batsman'];
                            $howout = $_POST['howout'];
                            $t_runs = $_POST['t_runs'];
                            $balls = $_POST['balls'];
                            $four = $_POST['four'];
                            $six = $_POST['six'];
                            $sr = $_POST['sr'];
                            $extra = $_POST['extra'];
                            $total = $_POST['total'];

                          

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO tbl_scorecard  (bat_teams,teams,batsman,howout,t_runs,balls,four,six,sr,extra,total) VALUES ('$bat_teams','$teams','$batsman','$howout','$t_runs','$balls','$four','$six','$sr','$extra','$total')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }






?>

<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM tbl_scorecard WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>

<div><p>Batting Details</p></div>

  <form action="a_scorecard.php" method="post">
    <div class="form-group">
      
      <input type="text" class="form-control" id="text1" placeholder="Enter Batting Team name" name="bat_teams" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Team names" name="teams" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Batsman Name" name="batsman" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Bowler Name & How Out" name="howout" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Batsman Total Runs" name="t_runs" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Faced Balls" name="balls" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter fours" name="four" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Sixes" name="six" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Strike Rate" name="sr" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Total Extras" name="extra" required=""><br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Total Runs" name="total" required=""><br>
      
      
      
    </div>
    <button type="submit" name="btnAd" class="btn btn-default">Submit</button>
  </form>

<br>
<h2>View Scores</h2>


</div>
</div>


<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>

<?php


$conn =  getDBconnection ();

?>
           

<h2>Batting</h2>

<table>
  <tr>
    <th>Batsman</th>
    <th>Bowler & How Out</th>
    <th>Runs</th>
    <th>Bowls</th>
    <th>4s</th>
    <th>6s</th>
    <th>SR</th>
    <th>Edit</th>
  </tr>

  <?php 

$sql = "SELECT * FROM tbl_scorecard";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>
  <tr>
    
    <td><?php echo $row['batsman'] ?></td>
    <td><?php echo $row['howout'] ?></td>
    <td><?php echo $row['t_runs'] ?></td>
    <td><?php echo $row['balls'] ?></td>
    <td><?php echo $row['four'] ?></td>
    <td><?php echo $row['six'] ?></td>
    <td><?php echo $row['sr'] ?></td>
    <td>
                <form action="a_scorecard.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  <a href="a_scorecard-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a>
                </form>
            </td>
    
    
  </tr>

  <center><h3><?php echo $row['bat_teams'] ?></h3></center>
<p><?php echo $row['teams'] ?></p>
  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>
  

</div></div>


</body>
</html>
