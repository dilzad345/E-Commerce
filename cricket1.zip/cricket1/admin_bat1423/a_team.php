

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Teams Profile Update</h2>



<?php
// insert data into the database 
include('../_function.php');


if (isset($_POST['btnAd'])) {

                            $name = $_POST['name'];
                            $photo = $_POST['photo'];

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO tbl_team  (name,photo) VALUES ('$name','$photo')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }

?>
<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM tbl_team WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>

  <form action="a_team.php" method="post">
    <div class="form-group">
      
      <input type="text" class="form-control" id="text1" placeholder="Enter Team Name" name="name" required="">
      <br>
      <input type="file" name="photo" required="">
    </div>
    <button type="submit" name="btnAd" class="btn btn-default">Submit</button>
  </form>
<br>
<h2>View Details</h2>

<style>
table {
  border-collapse: collapse;
  width: 100%;
 
}

th, td {
  text-align: center;
  padding: 8px;
height: 90px;
font-size: 18px;
}

tr:nth-child(even){background-color: #FDFEFE}

th {
  background-color: #979A9A;
  color: white;
}


</style>

<?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM tbl_team";
$result = mysqli_query($conn,$sql);

?>

<table>

<?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>

  
  <tr>
    <td><?php echo $row['id']?></td>
    <td><a href="https://www.facebook.com/dilshath.mohamed.39"><img src="../images/<?php echo $row['photo']?>" alt="M-dev-Store Logo" class="hidden-xs" height="80" width="120"></a></td> 
    <td><b><?php echo $row['name']?><b></td>
      <td>
                <form action="a_team.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  <a href="a_team-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a>
                </form>
            </td>
  </tr>

 <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>

</table>



</div>
</div>
</body>
</html>
