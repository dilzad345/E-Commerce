<!DOCTYPE html>
<html>
<title>Batti cricScore - Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<!-- Sidebar -->
<div class="w3-sidebar w3-light-grey w3-bar-block" style="width:15%">
  <a href="dashboard.php"><h3 class="w3-bar-item">Menu</h3></a>
  <a href="a_slides.php" class="w3-bar-item w3-button">Slide Images</a>
  <a href="news.php" class="w3-bar-item w3-button">News Update</a>
  <div class="w3-dropdown-hover">
    <button class="w3-button">Score
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="w3-dropdown-content w3-bar-block">
      <a href="a_liveScore.php" class="w3-bar-item w3-button">Live</a>
      <a href="a_recentScore.php" class="w3-bar-item w3-button">Recent</a>
      <a href="a_upcoming.php" class="w3-bar-item w3-button">Up Coiming</a>
    </div>
  </div> 
  <a href="a_schedule.php" class="w3-bar-item w3-button">Schedule</a>
  <a href="a_player.php" class="w3-bar-item w3-button">Players</a>
  <a href="a_player_profile.php" class="w3-bar-item w3-button">Players Profile</a>
  <a href="a_team.php" class="w3-bar-item w3-button">Teams</a>
  <a href="a_gallery.php" class="w3-bar-item w3-button">Gallery</a>
  <div class="w3-dropdown-hover">
    <button class="w3-button">Ranking
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="w3-dropdown-content w3-bar-block">
      <a href="r_batting.php" class="w3-bar-item w3-button">Batting</a>
      <a href="r_bowling.php" class="w3-bar-item w3-button">Bowling</a>
      <a href="r_points.php" class="w3-bar-item w3-button">Teams</a>
    </div>
  </div>
  <div class="w3-dropdown-hover">
    <button class="w3-button">Add Score
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="w3-dropdown-content w3-bar-block">
      <a href="a_scorecard.php" class="w3-bar-item w3-button">Batting Details</a>
      <a href="a_scorecard_bowl.php" class="w3-bar-item w3-button">Bowling Details</a>
      
    </div>
  </div> 
  <a href="points_table.php" class="w3-bar-item w3-button">Points</a>
  <a href="contact_msg.php" class="w3-bar-item w3-button">Contact</a>
  <a href="admin_registration.php" class="w3-bar-item w3-button">Admin Registration</a>
  <a href="admin_details.php" class="w3-bar-item w3-button">Admin Details</a>
  <a href="a_chat_box.php" class="w3-bar-item w3-button">Chat Box</a>
  <a href="logout.php" class="w3-bar-item w3-button">Logout</a>

</div>

<!-- Page Content -->
<div style="margin-left:15%">

<div class="w3-container w3-teal">
  <h1>Admin Pannel</h1>
</div>





</div>
      
</body>
</html>
