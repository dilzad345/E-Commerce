<!DOCTYPE html>


<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>



<?php
include('../_function.php');
$conn =  getDBconnection ();

$sql = "SELECT * FROM admin_details ORDER BY id DESC";
$result = mysqli_query($conn,$sql);

?>





</head>
<body>
<?php 

include("include/header.php");

 ?>


  

 <div style="margin-left:17%">

<h2>Admin Enter Details</h2>

<table>
  <tr>
    <th>User Name</th>
    <th>Date & Time</th>
    
    
  </tr>

  <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>
  <tr>
    <td><?php echo $row['username']?></td>
    <td><?php echo $row['date']?></td>
    
    

  </tr>

  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div>


</body>
</html>
