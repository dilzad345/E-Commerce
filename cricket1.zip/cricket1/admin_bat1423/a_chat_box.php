<?php 

include("include/header.php");

 ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<div style="margin-left:15%">
<style>


.container1 {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}

.darker {
  border-color: #ccc;
  background-color: #ddd;
}

.container1::after {
  content: "";
  clear: both;
  display: table;
}

.container1 img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.container1 img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
  size: 10px;
}

.time-left {
  float: left;
  color: #999;
}
</style>
</head>
<body>

  <?php
// insert data into the database 
include('../_function.php');


if (isset($_POST['submit'])) {

                            $message= $_POST['message'];
                            

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO chatting  (message) VALUES ('$message')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }

                          ?>

                          <?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM chatting WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>


<h2>Chat Messages</h2>

<?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM chatting";
$result = mysqli_query($conn,$sql);

?>

<table>

<?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>

<div class="container1">
  <img src="images/a.jpg" alt="Avatar" style="width:100%;">
  <p><?php echo $row['message']?></p>
  
  <span class="time-right"><?php echo $row['date_time'] ?></span>

</div>
 <form action="a_chat_box.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  
                </form>



<?php
                                    

                                    }
                                } else {
                                    echo "";
                                }

?>
<br><br>
<form action="a_chat_box.php" method="post">
<input type="text" class="form-control" name="message" >
&nbsp;&nbsp;&nbsp;
  <button type="submit" name="submit" class="btn btn-secondary">Submit</button>
</form>
</body>
</html>
