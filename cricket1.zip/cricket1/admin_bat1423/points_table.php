

 <!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Teams Points Table</h2>



<?php
// insert data into the database 
include('../_function.php');


if (isset($_POST['btnAd'])) {

                            $teams = $_POST['teams'];
                            $played = $_POST['played'];
                            $won = $_POST['won'];
                            $lost = $_POST['lost'];
                            $nr = $_POST['nr'];
                            $rate = $_POST['rate'];
                            $points = $_POST['points'];
                          

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO points_tbl  (teams,played,won,lost,nr,rate,points) VALUES ('$teams','$played','$won','$lost','$nr','$rate','$points')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }
?>
<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM points_tbl WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>

  <form action="points_table.php" method="post">
    <div class="form-group">
      
      <input type="text" class="form-control" id="text1" placeholder="Enter Team name" name="teams" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Played Matchs" name="played" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Won Matches" name="won" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Lost Matches" name="lost" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter N/R" name="nr" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Run Rate" name="rate" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Points" name="points" required="">
      
    </div>
    <button type="submit" name="btnAd" class="btn btn-default">Submit</button>
  </form>
<br>
<h2>View Details</h2>

<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
}
</style>
</head>



<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #FDFEFE;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #979A9A;
  color: white;
}
</style>
</head>
<body>







  

<br><br>

<?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM points_tbl ORDER BY points DESC";
$result = mysqli_query($conn,$sql);

?>


<table id="customers">
  <tr>
    <th>Teams</th>
    <th>Played</th>
    <th>Won</th>
    <th>Lost</th>
    <th>N/R</th>
    <th>R.Rate</th>
    <th>Points</th>
    <th>Edit</th>
    

  </tr>

   <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>

  <tr>
    <td><?php echo $row['teams']?></td>
    <td><?php echo $row['played']?></td>
    <td><?php echo $row['won']?></td>
    <td><?php echo $row['lost']?></td>
    <td><?php echo $row['nr']?></td>
    <td><?php echo $row['rate']?></td>
    <td><?php echo $row['points']?></td>
    <td>
                <form action="points_table.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  <a href="points_table-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a>
                </form>
            </td>
  </tr>
  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div></div>


</div>
</div>
</body>
</html>
