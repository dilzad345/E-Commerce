<!DOCTYPE html>


<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>



<?php
include('../_function.php');
$conn =  getDBconnection ();

$sql = "SELECT * FROM messege";
$result = mysqli_query($conn,$sql);

?>

<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM messege WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>



</head>
<body>
<?php 

include("include/header.php");

 ?>


  

 <div style="margin-left:17%">

<h2>MESSAGE</h2>

<table>
  <tr>
    <th>Name</th>
    <th>E-Mail</th>
    <th>Phone No</th>
    <th>Message</th>
    <th>Edit</th>
  </tr>

  <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>
  <tr>
    <td><?php echo $row['name']?></td>
    <td><?php echo $row['email']?></td>
    <td><?php echo $row['subject']?></td>
    <td><?php echo $row['messege']?></td>
    <td>
                <form action="contact_msg.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                </form>
            </td>

  </tr>

  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div>


</body>
</html>
