<?php
session_start();
include('../_function.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti Cric Score</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
   
   <?php

                            if (isset($_POST['admin_login'])) {
                                # code...
                                $username = $_POST['username'];
                                $password = $_POST['password'];

                                $conn = getDBconnection();

                                $sql = "SELECT * FROM a_reg WHERE username = '$username' AND password = '$password'";

                                $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {


                                    foreach ($result as $row) {

                                        
                                        header("location:dashboard.php");

                                    }

                                } else {
                                    echo "<script>alert('Incorrect Password OR Username')</script>";
                                }
                            }

                        ?>

                        <?php
// insert data into the database 


if (isset($_POST['admin_login'])) {

                            $username = $_POST['username'];
                          
                          $conn =  getDBconnection ();
                    $sql = "INSERT INTO admin_details  (username) VALUES ('$username')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "";
                                }
                                else {
                                    echo "";
                                }
                          }






?>

   <div class="container"><!-- container begin -->
       <form action="" class="form-login" method="post"><!-- form-login begin -->
           <h2 class="form-login-heading"> Admin Login </h2>
           
           <input type="text" class="form-control" placeholder="Enter Username" name="username" required>
           
           <input type="password" class="form-control" placeholder="Your Password" name="password" required>
           
           <button type="submit" class="btn btn-lg btn-primary btn-block" name="admin_login"><!-- btn btn-lg btn-primary btn-block begin -->
               
               Login
               
           </button><!-- btn btn-lg btn-primary btn-block finish -->
           
       </form><!-- form-login finish -->
   </div><!-- container finish -->
    
</body>
</html>




?>