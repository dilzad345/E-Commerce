<?php 

    $active='gallery';
    include("includes/header.php");

?>

<div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Ranking
                   </li>
                   <li>
                       Teams
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->

          <style>
.button {
  background-color: black; /* Green */
  border: none;
  color: white;
  padding: 5px;
  text-align: center;
  text-decoration: none;
  
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


.button4 {border-radius: 12px;}

</style>





<a href="ranking.php"> <button class="btn btn-info">Batting</button> </a> &nbsp;&nbsp;&nbsp;
<a href="bowling.php"> <button class="btn btn-info">Bowling</button> </a> &nbsp; &nbsp;&nbsp;
<a href="teams.php"> <button class="btn btn-info">Teams</button> </a> &nbsp; &nbsp;&nbsp;
<a href="points.php"> <button class="btn btn-info">Points Table</button> </a>
<br><br>

<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: center;
  padding: 8px;
  height: 50px;
}

tr:nth-child(even){background-color: #FDFEFE}

th {
  background-color: #979A9A;
  color: white;
}


</style>




<?php
include('_function.php');
$conn =  getDBconnection ();

$sql = "SELECT * FROM r_teams";
$result = mysqli_query($conn,$sql);

?>


<table>

  <tr>
    <td><b>Position<b></td>
    <td><b>Team<b></td>
    <td><b>points<b></td>
  </tr>
  <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>



  <tr>
    <td><b><?php echo $row['id']?><b></td>
    <td><b><?php echo $row['names']?><b></td>
    <td><b><?php echo $row['points']?><b></td>
  </tr>
  
  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div></div><br>
<br>
 <?php 
    
    include("includes/footer.php");
    
    ?>

<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>