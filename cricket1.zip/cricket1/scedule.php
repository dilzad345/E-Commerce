<?php 

    $active='SCHEDULE';
    include("includes/header.php");

?>

<div style="margin-left: 75%;">
    <form action="scedule.php" method="post"> 

<input type="text" name="team" placeholder="team" />
<input type="submit" name="btnSearch" value="Search" />
</form>
</div>

<br>

<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;

}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #FDFEFE;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #979A9A;
  color: white;
}
</style>
</head>
<body>

	<div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Schedule
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->

<table id="customers">
  <tr>
    <th>Teams</th>
    <th>Type</th>
    <th>Date & Time</th>
    <th>Ground</th>

  </tr>

  <?php

include('_function.php');
 $conn =  getDBconnection ();


if(isset($_POST['btnSearch']))
{
  $team = $_POST['team'];
  $sqlpname = "SELECT * FROM tbl_schedule WHERE team LIKE '%$team%'";
$result2 = mysqli_query($conn , $sqlpname);
  if (mysqli_num_rows($result2) > 0) {
                                    foreach ($result2 as $row) {
?>

Team Name : <?php echo $row['team'] ?> <br>
Match Type : <?php echo $row['type'] ?> <br>
Time : <?php echo $row['tyme'] ?> <br>
Ground : <?php echo $row['ground'] ?> 


<?php

                                    }}

}

?>

  <?php 

$conn =  getDBconnection ();
$sql = "SELECT * FROM tbl_schedule";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>

  <tr>
    <td><b><?php echo $row['team'] ?><b></td>
    <td><b><?php echo $row['type'] ?><b></td>
    <td><b><?php echo $row['tyme'] ?><b></td>
    <td><b><?php echo $row['ground'] ?><b></td>

  </tr>

  

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>

</table>
</div></div><br>
<br>
 <?php 
    
    include("includes/footer.php");
    
    ?>

</body>
</html>
