<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="styles/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>
		<div id="navbar" class="navbar navbar-default"><!-- navbar navbar-default Begin -->
       
       <div class="container"><!-- container Begin -->
           
           <div class="navbar-header"><!-- navbar-header Begin -->
               
               <a href="index.php" class="navbar-brand home"><!-- navbar-brand home Begin -->
                   
                   <img src="images/p6.png" alt="M-dev-Store Logo" class="hidden-xs" height="55" width="80">
                   <img src="images/p6.png" alt="M-dev-Store Logo Mobile" class="visible-xs" height="55" width="80">
                   
               </a><!-- navbar-brand home Finish -->
               
               <button class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                   
                   <span class="sr-only">Toggle Navigation</span>
                   
                   <i class="fa fa-align-justify"></i>
                   
               </button>
               
               <button class="navbar-toggle" data-toggle="collapse" data-target="#search">
                   
                   <span class="sr-only">Toggle Search</span>
                   
                   <i class="fa fa-search"></i>
                   
               </button>
               
           </div><!-- navbar-header Finish -->
           
           <div class="navbar-collapse collapse" id="navigation"><!-- navbar-collapse collapse Begin -->
               
               <div class="padding-nav"><!-- padding-nav Begin -->
                   
                   <ul class="nav navbar-nav left"><!-- nav navbar-nav left Begin -->
                       
                       <li class="">
                           <a href="live_score.php">Live Score</a>
                       </li>
                       <li>
                           <a href="scedule.php">Scedule</a>
                       </li>
                       <li>
                           <a href="player.php">Players</a>
                       </li>
                       
                       <li>
                           <a href="team.php" for="cars">Teams</a>
                       </li>
                       <li>
                           <a href="gallery.php">Gallery</a>
                       </li>
                       <li>
                           <a href="ranking.php">Rankings</a>
                       </li>
                       <li>
                           <a href="players_profile.php">Create Player Profile</a>
                       </li>
                       <li>
                           <a href="chat_box.php">Live Chat</a>
                       </li>
                       <li>
                           <a href="contact.php">Contact Us</a>
                       </li>
                       
                   </ul><!-- nav navbar-nav left Finish -->
                   
               </div><!-- padding-nav Finish -->
               
               
      <center>       
    
    


    


    <div id="box" ></div>
    <script src="jquery.js"></script>
  </div>

</center>  

</div><!-- navbar-collapse collapse Finish -->
</div><!-- container Finish -->
    <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
</body>
</html>