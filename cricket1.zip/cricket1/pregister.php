<?php

include ("function.php");
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>DemoCRUD</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>

        <link href="css/sms-style.css" rel="stylesheet" type="text/css"/>

        
        <script> 
        
         var myva1 = "RAvinath";
         
         function getAlertMy(v1){
            alert('js working'+v1);  
         }
         
//         getAlertMy(myva1);
         
         
         
        
         
        </script>
        
        
    </head>
    <body>

        <div class="container">

            <div class="row">
                <div class="col-12" id="headDiv">
                    <h3>DemoCRUD</h3>
                </div>
            </div>

            <div class="row" id="lineDiv">
                <div class="col-9"></div>
                <div class="col-3">&nbsp;</div>
            </div>

            <div class="row">
                <div class="col-3">
                </div>

                <div class="col-6">
                    <h2>Register</h2>

                    <?php

                    if (isset($_POST['btnReg'])) {

                            $first_name = $_POST['first_name'];
                            $last_name = $_POST['last_name'];
                            $gender = $_POST['gender'];
                            $address = $_POST['address'];
                            $age = $_POST['age'];
                            $pword = $_POST['pword'];
                            $repword = $_POST['repword'];
                            $subject_id = $_POST['subject_id'];
                            $dob = $_POST['dob'];
                            $username = $_POST['username'];
                            


                                $conn = getDBconnection();

                                $sql = "INSERT INTO s1 (first_name,last_name,gender,address,age,pword,subject_id,dob,username) VALUES ('$first_name','$last_name','$gender','$address','$age','$pword','$subject_id','$dob','$username')";

                                if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }


                            }

                     ?>

                    <span class="mando"></span>
                    <form action="register.php" method="post" onsubmit="return validateRegStudent()">

                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 col-form-label">First Name <span class="mando">*</span></label>
                            <div class="col-sm-8">
                                <input type="text" name="first_name" class="form-control" id="first_name" required="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 col-form-label">Last Name <span class="mando">*</span></label>
                            <div class="col-sm-8">
                                <input type="text" name="last_name" class="form-control" id="last_name"  required=""/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Gender</label>
                            <div class="col-sm-10">
                                <input type="radio" name="gender" value="male" checked="" /> Male
                                <input type="radio" name="gender" value="female" /> Female
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Address</label>
                            <div class="col-sm-10">
                                <textarea name="address" class="form-control"> </textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Age</label>
                            <div class="col-sm-10">
                                <input type="text" name="age" class="form-control" id="inputEmail3" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Subject</label>
                            <div class="col-sm-10">
                                <select name="subject_id" class="form-control" >
                                    <option>--select subject--</option>
                                    <option value="1">Science</option>
                                    <option value="2">Math</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Date of Birth</label>
                            <div class="col-sm-10">
                                <input type="date" name="dob" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Username *</label>
                            <div class="col-sm-10">
                                <input type="text" name="username" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
                            <div class="col-sm-10">
                                <input type="password" name="pword" class="form-control" id="inputPassword3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Retype Password</label>
                            <div class="col-sm-10">
                                <input type="password" name="repword" class="form-control" id="inputPassword3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btnReg" class="btn btn-primary">Register</button>
                                <button type="button" name="" class="btn btn-primary" onclick="validateRegStudent()">Test</button>
                            </div>
                        </div>
                    </form>

                </div>

                <div class="col-3">
                </div>
            </div>

        </div> 

    </body>
    
       <script>
           
         function validateRegStudent(){
              var first_name = document.getElementById('first_name').value;
//               alert(first_name);
              if(first_name == ''){
                  alert('First Name is empty'); 
                  return false;
              }
              
              return true;
         }
         
        </script>
</html>