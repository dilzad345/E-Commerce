<?php 

    $active='gallery';
    include("includes/header.php");

?>

<div style="margin-left: 75%;">
    <form action="bowling.php" method="post"> 

<input type="text" name="team_name" placeholder="Player Name" />
<input type="submit" name="btnSearch" value="Search" />
</form>
</div>

<br>

<div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Ranking
                   </li>
                   <li>
                       Bowling
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->

          <style>
.button {
  background-color: black; /* Green */
  border: none;
  color: white;
  padding: 5px;
  text-align: center;
  text-decoration: none;
  
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


.button4 {border-radius: 12px;}

</style>





<a href="ranking.php"> <button class="btn btn-info">Batting</button> </a> &nbsp;&nbsp;&nbsp;
<a href="bowling.php"> <button class="btn btn-info">Bowling</button> </a> &nbsp; &nbsp;&nbsp;
<a href="teams.php"> <button class="btn btn-info">Teams</button> </a> &nbsp; &nbsp;&nbsp;
<a href="points.php"> <button class="btn btn-info">Points Table</button> </a>

<br><br>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: center;
  padding: 8px;
height: 50px;
}

tr:nth-child(even){background-color: #FDFEFE}

th {
  background-color: #979A9A;
  color: white;
}


</style>

<?php

include('_function.php');
 $conn =  getDBconnection ();


if(isset($_POST['btnSearch']))
{
  $team_name = $_POST['team_name'];
  $sqlpname = "SELECT * FROM r_bowling WHERE team_name LIKE '%$team_name%'";
$result2 = mysqli_query($conn , $sqlpname);
  if (mysqli_num_rows($result2) > 0) {
                                    foreach ($result2 as $row) {
?>

Player Name : <?php echo $row['name'] ?> <br>
Team Name : <?php echo $row['team_name'] ?> <br>
Player Wickets : <?php echo $row['wickets'] ?> <br>

<?php

                                    }}

}

?>


<?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM r_bowling ORDER BY wickets DESC";
$result = mysqli_query($conn,$sql);

?>


<table>

  <tr>
    <td><b>Players<b></td>
    <td><b>Team Name<b></td>
    <td><b>Wickets<b></td>
  </tr>
  <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>



  <tr>
    <td><b><?php echo $row['team_name']?><b></td>
    <td><b><?php echo $row['name']?><b></td>
    <td><b><?php echo $row['wickets']?><b></td>
  </tr>
  
  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div></div><br>
<br>
 <?php 
    
    include("includes/footer.php");
    
    ?>

<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>