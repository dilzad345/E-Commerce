<?php 

    $active='archeive';
    include("includes/header.php");
    include('_function.php');

?>

<?php

                    if (isset($_POST['btnReg'])) {

                            $firstname = $_POST['firstname'];
                            $lastname = $_POST['lastname'];
                            
                            $address = $_POST['address'];
                            $nic = $_POST['nic'];
                            $bdca_no = $_POST['bdca_no'];
                            $age = $_POST['age'];
                            $dob = $_POST['dob'];
                            $email = $_POST['email'];
                            $profile_photo = $_POST['profile_photo'];
                            
                            
                            


                                $conn = getDBconnection();

                                $sql = "INSERT INTO tbl_playerprofile (firstname,lastname,address,nic,bdca_no,age,dob,email,profile_photo) VALUES ('$firstname','$lastname','$address','$nic','$age','$dob','$email','$dob','$profile_photo')";

                                if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }


                            }

                            
                            




                           
                    

                             

                     ?>

<!DOCTYPE html>
<html>
<head>
	<title>Players Profile</title>
<div>
	<style>
.fname {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  text-align: center;
}




.submit{
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

</div>


</style>
</head>
<body>
<br>
<h3 align="center"><b>CRAETE PLAYERS PROFILE</b></h3>

<hr>

<div style="margin-left: 15%; margin-right:15%">
<div class="form">
  <form action="" method="post">
    <label for="fname"></label>
    <input type="text" class="fname" name="firstname" placeholder="Enter Your Full Name.." required="">

    <label for="lname"></label>
    <input type="text" class="fname" name="lastname" placeholder="Enter Your Team Name.." required="">

    

    <label for="fname"></label>
    <input type="text" class="fname" name="address" placeholder="Enter Your Address.." required="">

    <label for="fname"></label>
    <input type="text" class="fname" name="nic" placeholder="Enter Your Nic.." required="">

    <label for="fname"></label>
    <input type="text" class="fname" name="bdca_no" placeholder="Enter Your BDCA No.." required="">

    <label for="fname"></label>
    <input type="text" class="fname" name="age" placeholder="Enter Your Age.." required="">

    <label for="fname"></label>
    <input type="Date" class="fname" name="dob" placeholder="Enter Your Date of Birth.." required="">

    <label for="fname"></label>
    <input type="E-mail" class="fname" name="email" placeholder="Enter Your Email.." required="">

    
                <label class="header">Profile Photo:</label>
                
                <input id="image" type="file" name="profile_photo" placeholder="Photo" required="" capture>
            
  
    <input type="submit" class="submit" value="Submit" name="btnReg">
  </form>
  </div>
</div>
<br><br>
<?php 
    
    include("includes/footer.php");
    
    ?>
</body>
</html>

<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>