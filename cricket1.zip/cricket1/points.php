<?php 

    $active='live_score';
    include("includes/header.php");

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
}
</style>
</head>
<style>
.button {
  background-color: black; /* Green */
  border: none;
  color: white;
  padding: 5px;
  text-align: center;
  text-decoration: none;
  
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


.button4 {border-radius: 12px;}

</style>


<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #FDFEFE;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #979A9A;
  color: white;
}
</style>
</head>
<body>







  <div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Live Scores
                   </li>
                   <li>
                       Points Table
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->
<div>
<a href="ranking.php"> <button class="btn btn-info">Batting</button> </a> &nbsp;&nbsp;&nbsp;
<a href="bowling.php"> <button class="btn btn-info">Bowling</button> </a> &nbsp; &nbsp;&nbsp;
<a href="teams.php"> <button class="btn btn-info">Teams</button> </a> &nbsp; &nbsp;&nbsp;
<a href="points.php"> <button class="btn btn-info">Points Table</button> </a>
</div>
<br><br>

<?php
include('_function.php');
$conn =  getDBconnection ();

$sql = "SELECT * FROM points_tbl ORDER BY points DESC";
$result = mysqli_query($conn,$sql);

?>


<table id="customers">
  <tr>
    <th>Teams</th>
    <th>Played</th>
    <th>Won</th>
    <th>Lost</th>
    <th>N/R</th>
    <th>R.Rate</th>
    <th>Points</th>
    

  </tr>

   <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>

  <tr>
    <td><?php echo $row['teams']?></td>
    <td><?php echo $row['played']?></td>
    <td><?php echo $row['won']?></td>
    <td><?php echo $row['lost']?></td>
    <td><?php echo $row['nr']?></td>
    <td><?php echo $row['rate']?></td>
    <td><?php echo $row['points']?></td>
  </tr>
  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div></div><br>
<br>
 <?php 
    
    include("includes/footer.php");
    
    ?>

</body>
</html>




<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>



