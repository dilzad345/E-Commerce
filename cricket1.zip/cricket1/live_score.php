<?php 

    $active='live_score';
    include("includes/header.php");

?>

<div style="margin-left: 75%;">
    <form action="live_score.php" method="post"> 

<input type="text" name="team_names" placeholder="Team Name" />
<input type="submit" name="btnSearch" value="Search" />
</form>
</div>

<br>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #ABEBC6;
}

.button {
  background-color: black; /* Green */
  border: none;
  color: white;
  padding: 5px;
  text-align: center;
  text-decoration: none;
  
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


.button4 {border-radius: 12px;}

</style>

</head>






<body>

  <div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Live Scores
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->
<div>
<a href="live_score.php"> <button class="btn btn-info">Live Score</button> </a> &nbsp;&nbsp;&nbsp;
<a href="recent.php"> <button class="btn btn-info">Recent</button> </a> &nbsp; &nbsp;&nbsp;
<a href="up_coming.php"> <button class="btn btn-info">Up Coming</button> </a> </a>&nbsp; &nbsp;&nbsp;

</div>
</div>
</div>
<br><br>


<?php

include('_function.php');
 $conn =  getDBconnection ();


if(isset($_POST['btnSearch']))
{
  $team_names = $_POST['team_names'];
  $sqlpname = "SELECT * FROM tbl_live WHERE team_names LIKE '%$team_names%'";
$result2 = mysqli_query($conn , $sqlpname);
  if (mysqli_num_rows($result2) > 0) {
                                    foreach ($result2 as $row) {
?>

Team Name : <?php echo $row['team_names'] ?> <br>
Score :           <?php echo $row['score'] ?> <br>
Ground :    <?php echo $row['ground'] ?>


<?php

                                    }}

}

?>

 
 <?php 

$conn =  getDBconnection ();
$sql = "SELECT * FROM tbl_live";
$result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>




<<br>
  <div style="margin-right: 20%;">
    <div class="card" style="margin-left:20%">
      <b><p><?php echo $row['team_names'] ?></p> <b>
      <p><?php echo $row['score'] ?></p>
      <p><?php echo $row['ground'] ?></p> 
      <a href="score_card.php"><b>Score Card</b></a>

</div></div>
       
    </div>
  </div>
</div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>


 

<br><br>
 <?php 
    
    include("includes/footer.php");
    
    ?>


</div>
</div>


<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
</body>
</html>