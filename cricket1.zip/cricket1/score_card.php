<?php 

    $active='live_score';
    include("includes/header.php");

?>


<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

  <div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Live Scores
                   </li>
                    <li>
                       Score Card
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->
<?php

include('_function.php');
$conn =  getDBconnection ();

?>
           

<h2>Batting</h2>

<table>
  <tr>
    <th>Batsman</th>
    <th>Bowler & How Out</th>
    <th>Runs</th>
    <th>Bowls</th>
    <th>4s</th>
    <th>6s</th>
    <th>SR</th>
  </tr>

  <?php 

$sql = "SELECT * FROM tbl_scorecard";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>
  <tr>
    
    <td><?php echo $row['batsman'] ?></td>
    <td><?php echo $row['howout'] ?></td>
    <td><?php echo $row['t_runs'] ?></td>
    <td><?php echo $row['balls'] ?></td>
    <td><?php echo $row['four'] ?></td>
    <td><?php echo $row['six'] ?></td>
    <td><?php echo $row['sr'] ?></td>
    
    
  </tr>

  <center><h3><?php echo $row['bat_teams'] ?></h3></center>
<p><?php echo $row['teams'] ?></p>
  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>
  
</table>
<br><br>

<h2>Bowling</h2>

<table>
  <tr>
    <th>Bowling</th>
    
    <th>O</th>
    <th>R</th>
    <th>M</th>
    <th>W</th>
    <th>Econ</th>
  </tr>

  <?php 

$sql = "SELECT * FROM tbl_scorebowl";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>

  <tr>
    
    <td><?php echo $row['bowler'] ?></td>
    <td><?php echo $row['run'] ?></td>
    <td><?php echo $row['madin'] ?></td>
    <td><?php echo $row['wicket'] ?></td>
    <td><?php echo $row['economic'] ?></td>
    <td><?php echo $row['overs'] ?></td>
  </tr>

  <p><?php echo $row['bowling_teams'] ?></p>

   <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>
  
</table>
</div></div><br>
<br>
 <?php 
    
    include("includes/footer.php");
    
    ?>

</body>
</html>
