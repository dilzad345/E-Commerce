<?php 

    $active='gallery';
    include("includes/header.php");

?>

<div style="margin-left: 75%;">
    <form action="gallery.php" method="post"> 

<input type="text" name="teams" placeholder="Team Name" />
<input type="submit" name="btnSearch" value="Search" />
</form>
</div>
<br>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Gallery</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head> 
<body>

<div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Gallery
                   </li>
               </ul><!-- breadcrumb Finish -->
               
          </div></div>



<?php

include('_function.php');
 $conn =  getDBconnection ();


if(isset($_POST['btnSearch']))
{
  $teams = $_POST['teams'];
  $sqlpname = "SELECT * FROM tbl_gallery WHERE teams LIKE '%$teams%'";
$result2 = mysqli_query($conn , $sqlpname);
  if (mysqli_num_rows($result2) > 0) {
                                    foreach ($result2 as $row) {
?>
 <?php echo $row['teams'] ?> <br>
<img src="images/<?php echo $row['photos']?>" alt="M-dev-Store Logo" class="hidden-xs" height="250" width="400">
<?php

                                    }}

}

?>
           

<div class="container">


  
  <div class="row">
    <div class="col-md-4">
      
    <?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM tbl_gallery";
$result = mysqli_query($conn,$sql);

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  

?>

 



<p>
<?php echo $row['teams']?>
</p>

<img src="images/<?php echo $row['photos']?>" alt="M-dev-Store Logo" class="hidden-xs" height="250" width="400">
<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
    



 <div class="caption">
            
          </div>
        </a>
      </div>
    </div></div></div>



<br>
<div class="col-md-12">
 <?php 
    
    include("includes/footer.php");
    
    ?>
</div>

<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>

    </body> 
</html> 